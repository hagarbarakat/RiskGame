package com.example.alexlaptop.riskgame;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Switch;

import com.github.chrisbanes.photoview.PhotoView;

public class egypt extends AppCompatActivity {

    Switch zoom;
    public static final String TAG = "MyActivity";

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_egypt);
        zoom = (Switch) findViewById(R.id.switch2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // egy=(ImageView)findViewById(R.id.egy) ;
        final PhotoView photoView = (PhotoView) findViewById(R.id.egy);
        photoView.setImageResource(R.drawable.egy);

        if (!zoom.isChecked()) {
            photoView.setOnTouchListener(new PhotoView.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {

                    Bitmap bmp = ((BitmapDrawable) photoView.getDrawable()).getBitmap();
                    float x = event.getX();
                    float y = event.getY();

                    try {
                        int pixel = bmp.getPixel((int) x, (int) y);
                        int redValue = Color.red(pixel);
                        int blueValue = Color.blue(pixel);
                        int greenValue = Color.green(pixel);
                        String red = Integer.toString(redValue);
                        String blue = Integer.toString(blueValue);
                        String green = Integer.toString(greenValue);
                        Snackbar.make(photoView, "Action done", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        Log.e(TAG, red + green + blue);
                        //color.setText(redValue+blueValue+greenVlue);
                    } catch (Exception e) {
                    }

                    return false;
                }

            });
        }
    }
}
