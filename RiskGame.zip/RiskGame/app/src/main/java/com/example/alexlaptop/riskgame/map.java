package com.example.alexlaptop.riskgame;

import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.graphics.Canvas;
import android.os.Bundle;
//import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class map extends AppCompatActivity implements OnClickListener {

    TextView egypt;
    TextView usa;

    public static final String TAG = "MyActivity";

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


    }
//public set
    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.egy: {
                startActivity(new Intent(map.this, egypt.class));
                break;
            }
            case R.id.usa: {
                startActivity(new Intent(map.this, united.class));
                break;
            }

        }
    }
}
