package com.example.alexlaptop.riskgame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class CustomView extends View {
    Bitmap TheBitmap;
    public CustomView(Context context) {
        super(context);
        init();
    }

    public CustomView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CustomView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setBackgroundColor(Color.DKGRAY);
    }

    public boolean onTouchEvent( View view,MotionEvent event) {
        TheBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.texas);

        super.onTouchEvent(event);
        int iX = (int) event.getX();
        int iY = (int) event.getY();
        int eventPadTouch = event.getAction();

        switch (eventPadTouch) {

            case MotionEvent.ACTION_DOWN:

                if (iX >= 0 & iY >= 0 & iX < TheBitmap.getWidth() & iY < TheBitmap.getHeight()) { // ** Makes sure that X and Y are not less than 0, and no more than the height and width of the image.
                    if (TheBitmap.getPixel(iX, iY) != 0) {
                        Toast.makeText(getContext(), "Missile launched", Toast.LENGTH_SHORT).show();
                    }

                }
                return true;
        }
        return false;
    }

    @Override
    public boolean performClick() {
        super.performClick();

        launchMissile();

        return true;
    }

    private void launchMissile() {
        Toast.makeText(getContext(), "Missile launched", Toast.LENGTH_SHORT).show();
    }
}

