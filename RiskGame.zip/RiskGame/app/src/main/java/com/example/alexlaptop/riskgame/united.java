package com.example.alexlaptop.riskgame;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.TextView;

import com.github.chrisbanes.photoview.PhotoViewAttacher;

public class united extends AppCompatActivity {

    private int rgb;
    ImageView usa;
    TextView color;

    public static final String TAG = "MyActivity";

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_united);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        usa = (ImageView) findViewById(R.id.usa);
        PhotoViewAttacher photoview = new PhotoViewAttacher(usa);
        photoview.update();

//        usa.setOnTouchListener(new ImageView.OnTouchListener() {
//
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                Bitmap bmp = ((BitmapDrawable) usa.getDrawable()).getBitmap();
//                        float x= event.getX();
//                        float y= event.getY();
//
//                try {
//                    int pixel = bmp.getPixel((int) x, (int) y);
//                    int redValue = Color.red(pixel);
//                    int blueValue = Color.blue(pixel);
//                    int greenValue = Color.green(pixel);
//                    String red = Integer.toString(redValue);
//                    String blue = Integer.toString(blueValue);
//                    String green = Integer.toString(greenValue);
//                    Snackbar.make(usa, "Action done", Snackbar.LENGTH_LONG)
//                            .setAction("Action", null).show();
//                    Log.e(TAG, red +green +blue );
//                    //color.setText(redValue+blueValue+greenVlue);
//                } catch (Exception e) {
//                }
//
//                return false;
//            }
//
//
//        });
//}
    }
}
