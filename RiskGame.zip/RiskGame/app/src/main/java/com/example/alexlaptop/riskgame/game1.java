package com.example.alexlaptop.riskgame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class game1 extends AppCompatActivity implements View.OnClickListener{

    TextView greedy;
    ImageButton icon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game1);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        greedy=(TextView)findViewById(R.id.greedy);
        icon=(ImageButton)findViewById(R.id.icon);


    }
    public void setUp(){}

    public void onClick(View v) {
        int id= v.getId();
        switch(id){
            case R.id.icon:{
                startActivity(new Intent(game1.this, map.class));
            }
            case R.id.greedy:
            {
                startActivity(new Intent(game1.this, map.class));
            }
        }
    }
}
