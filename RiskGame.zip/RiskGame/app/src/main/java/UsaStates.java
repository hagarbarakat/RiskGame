import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import com.example.alexlaptop.riskgame.R;

public class statetes  {

    String state;
      int color;
    public String getState( int col){
        switch (col) {
            case 203152223:
            {state="Alaska";
                break;}
            case  104114162:
            {
                state="Hawaii";
                break;
            }
            case 2191212:
            {
                state="Texas";
                break;
            }
            case 1273257:
            {
                state="Georgia";
                break;
            }
            case 201139139:
            {
                state= "Nevada";
                break;
            }
            case 21713252:
            {
                state="California";
                break;
            }
            case 6652217:
            {
                state="Arizona";
                break;
            }
            case 12219191:
            {
                state="Florida";
                break;
            }
            case 25517980:
            {
                state="Alabama";
                break;
            }
            case 80194255:
            {
                state="Mississippi";
                break;
            }
            case 56104102:
            {
                state="Louisiana";
                break;
            }
            case 152223175:
            {
                state="Arkansas";
                break;
            }
            case 5221785:
            {
                state="New Mexico";
                break;
            }
            case 1468812:
            {
                state="Kansas";
                break;
            }
            case 12153219:
            {
                state="Oklahoma";
                break;
            }
            case 21916412:
            {
                state="Utah";
                break;
            }
            case 12672101:
            {
                state="Colorado";
                break;
            }
            case 248177217:
            {
                state="Missouri";
                break;
            }
            case 1711010:
            {
                state="Oregon";
                break;
            }
            case 248177177:
            {
                state="Washington";
                break;
            }
            case 4110034:
            {
                state="Idaho";
                break;
            }
            case 21912126:
            {
                state="Montana";
                break;
            }
            case 48103129:
            {
                state="Wyoming";
                break;
            }
            case 219157145:
            {
                state="North Dakota";
                break;
            }
            case 144106121:
            {
                state="South Dakota";
                break;
            }
            case 12219157:
            {
                state="Nebraska";
                break;
            }
            case 177230248:
            {
                state="Minnesota";
                break;
            }
            case 173104104:
            {
                state="Iowa";
                break;
            }
            case 219211145:
            {
                state="Wisconsin";
                break;
            }
            case 111173104:
            {
                state="Illinois";
                break;
            }
            case 6348129:
            {
                state="Michigan";
                break;
            }
            case 1273283:
            {
                state="Indiana";
                break;
            }
            case 33255244:
            {
                state="Ohio";
                break;
            }
            case 177248178:
            {
                state="Pennsylvania";
                break;
            }
            case 88147161:
            {
                state="Maryland";
                break;
            }
            case 219145184:
            {
                state="West Virginia";
                break;
            }
            case 2555858:
            {
                state="Kentucky";
                break;
            }
            case 154152223:
            {
                state="Tennessee";
                break;
            }
            case 25523229:
            {
                state="South Carolina";
                break;
            }
            case 11833255:
            {
                state="North Carolina";
                break;
            }
            case 152223218:
            {
                state="Virginia";
                break;
            }
            case 1629494:
            {
                state="Delaware";
                break;
            }
            case 6115085:
            {
                state="New Jersey";
                break;
            }
            case 1826969:
            {
                state="Connecticut";
                break;
            }
            case 177234248:
            {
                state="Rhode Island";
                break;
            }
            case 61150135:
            {
                state="Vermont";
                break;
            }
            case 248220177:
            {
                state="New York";
                break;
            }
            case 158173136:
            {
                state="Maine";
                break;
            }
            case 7716843:
            {
                state="Massachusetts";
                break;
            }
            case 6988182:
            {
                state="New Hampshire";
                break;
            }

        }
return state;
    }
    public int getColor( String state){
        switch (state) {
            case "Alaska":
            {color=203152223;
                break;}
            case  "Hawaii":
            {
                color=104114162;
                break;
            }
            case "Texas":
            {
                color=2191212;
                break;
            }
            case "Georgia":
            {
                color=1273257;
                break;
            }
            case "Nevada":
            {
                color= 201139139;
                break;
            }
            case "California":
            {
                color=21713252;
                break;
            }
            case "Arizona":
            {
                color=6652217;
                break;
            }
            case"Florida" :
            {
                color=12219191;
                break;
            }
            case "Alabama":
            {
                color=25517980;
                break;
            }
            case "Mississippi":
            {
                color=80194255;
                break;
            }
            case "Louisiana":
            {
                color=56104102;
                break;
            }
            case "Arkansas":
            {
                color=152223175;
                break;
            }
            case "New Mexico":
            {
                color=5221785;
                break;
            }
            case "Kansas":
            {
                color=1468812;
                break;
            }
            case "Oklahoma":
            {
                color=12153219;
                break;
            }
            case "Utah":
            {
                color=21916412;
                break;
            }
            case "Colorado":
            {
                color=12672101;
                break;
            }
            case "Missouri":
            {
                color=248177217;
                break;
            }
            case "Oregon":
            {
                color=1711010;
                break;
            }
            case "Washington":
            {
                color=248177177;
                break;
            }
            case "Idaho":
            {
                color=4110034;
                break;
            }
            case "Montana":
            {
                color=21912126;
                break;
            }
            case "Wyoming":
            {
                color=48103129;
                break;
            }
            case "North Dakota":
            {
                color=219157145;
                break;
            }
            case "South Dakota":
            {
                color=144106121;
                break;
            }
            case "Nebraska":
            {
                color=12219157;
                break;
            }
            case "Minnesota":
            {
                color=177230248;
                break;
            }
            case "Iowa":
            {
                color=173104104;
                break;
            }
            case "Wisconsin":
            {
                color=219211145;
                break;
            }
            case "Illinois":
            {
                color=111173104;
                break;
            }
            case "Michigan":
            {
                color=6348129;
                break;
            }
            case "Indiana":
            {
                color=1273283;
                break;
            }
            case "Ohio":
            {
                color=33255244;
                break;
            }
            case "Pennsylvania":
            {
                color=177248178;
                break;
            }
            case "Maryland":
            {
                color=88147161;
                break;
            }
            case "West Virginia":
            {
                color=219145184;
                break;
            }
            case "Kentucky":
            {
                color=2555858;
                break;
            }
            case "Tennessee":
            {
                color=154152223;
                break;
            }
            case "South Carolina":
            {
                color=25523229;
                break;
            }
            case "North Carolina":
            {
                color=11833255;
                break;
            }
            case "Virginia":
            {
                color=152223218;
                break;
            }
            case "Delaware":
            {
                color=1629494;
                break;
            }
            case "New Jersey":
            {
                color=6115085;
                break;
            }
            case "Connecticut":
            {
                color=1826969;
                break;
            }
            case "Rhode Island":
            {
                color=177234248;
                break;
            }
            case "Vermont":
            {
                color=61150135;
                break;
            }
            case "New York" :
            {
                color=248220177;
                break;
            }
            case "Maine":
            {
                color=158173136;
                break;
            }
            case "Massachusetts":
            {
                color=7716843;
                break;
            }
            case "New Hampshire" :
            {
                color=6988182;
                break;
            }

        }
        return color;
    }

public int attackFrom (String color){
     int territory;
     territory=getColor(color);

        return territory ;
}
    public int attackTo (String color){
        int territory;
        territory=getColor(color);



        return territory;
    }
    public int attackResult (String color){
        int territory;
        territory=getColor(color);

        return territory;
    }

}