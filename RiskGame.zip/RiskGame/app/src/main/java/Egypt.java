public class Egypt {
    String states;

    public String getStates(int color) {

        switch (color) {
            case 11020463: {
                states = "New Valley";
                break;
            }
            case 163111198: {
                states = "Aswan";
                break;
            }
            case 19980143: {
                states = "Marsa Matrouh";
                break;
            }
            case 111156198: {
                states = " Red Sea";
                break;
            }
            case 952562: {
                states = "Giza";
                break;
            }
            case 253206188: {
                states = "Minya";
                break;
            }
            case 12357216: {
                states = "South Sinai";
                break;
            }
            case 489525: {
                states = "North Sinai";
                break;
            }
            case 57102216: {
                states = "Luxor";
                break;
            }
            case 21610757: {
                states = "Suez";
                break;
            }
            case 791573: {
                states = "Sohag";
                break;
            }
            case 217253188: {
                states = "Sharqia";
                break;
            }
            case 5020511:
            {
                states = "Qalyubia";
                break;
            }
            case 6210955 :{
                states = "Cairo";
                break;
            }
            case 253236188 :{
                states = "Fayoum";
                break;
            }

        }

return states;
    }

}
